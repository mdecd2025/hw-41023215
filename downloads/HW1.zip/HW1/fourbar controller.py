from controller import Robot

def run_robot():
  # Create the Robot instance
  robot = Robot()
  
  #Get simulation time step
  timestep = int(robot.getBasicTimeStep())
  
  #Get motor device
  motor = robot.getDevice('motor')
  
  #Set moter for continuous rotation
  motor.setPosition(float('inf'))
  # 初始設定馬達速度為0(暫停狀態)
  motor.setVelocity(1.0)
  
  #Main control loop
  while robot.step(timestep) != -1:
   pass
   
if _name_ == "_main_":
  run_robot()   
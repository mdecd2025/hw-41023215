import math
basket_ball_circumference = 75 # cm
basket_ball_radius = basket_ball_circumference/(2.0*math.pi)
print(basket_ball_radius)
